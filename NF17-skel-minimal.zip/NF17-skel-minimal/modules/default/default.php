<!-- ICI J'UTILISE LE HTML!!! LE PHP N'EST UTILISÉ QUE POUR LES BOUCLES
L'INITIALISATION DE MES VARIABLES PHP SE FONT DANS LE MODULE! -->

<h1>Bienvenue sur mon site</h1>

<fieldset>
	<legend>Liste de mes articles</legend>
</fieldset>


